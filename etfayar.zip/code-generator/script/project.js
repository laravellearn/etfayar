function run(data) {
    /** @type {DataForScript} */
    const ddd = data

    /**
     * write code below
     * it will be executed before generating files
     */
}
