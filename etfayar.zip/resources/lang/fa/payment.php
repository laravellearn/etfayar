<?php
return [
    'title' => 'پرداخت ها',
    'add' => 'افزودن پرداخت',
    'edit' => 'ویرایش پرداخت',
    'bank' => 'بانک',
    'price' => 'قیمت',
    'payment_receipt' => 'رسید پرداخت',
    'is_deposit' => 'آیا بیعانه است؟',
    'description' => 'توضیحات',
    'type' => 'نوع',
    'is_agree' => 'تایید واریزی',
    'agree' => 'تایید واریزی',
    'disagree' => 'عدم تایید واریزی',
    'agree_payment' => 'تایید واریزی',
    'disagree_payment' => 'عدم تایید واریزی',
    'are_you_sure_to_agree' => 'آیا از تایید واریزی اطمینان دارید؟',
    'are_you_sure_to_disagree' => 'آیا از عدم تایید واریزی اطمینان دارید؟',
];
